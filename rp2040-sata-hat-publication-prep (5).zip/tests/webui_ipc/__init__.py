"""Automated development tests."""
